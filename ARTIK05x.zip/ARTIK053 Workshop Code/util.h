#include <apps/netutils/mqtt_api.h>
#include <tinyara/gpio.h>

#include "info.h"

// NTP
#define NTP_REFRESH_PERIOD  (60 * 60) /* seconds */
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
#define RED_ON_BOARD_LED 45
#define ADC_MAX_SAMPLES 4
#define NET_DEVNAME "wl1"
#define DEFAULT_CLIENT_ID "123456789"
#define SERVER_ADDR "api.artik.cloud"//"52.200.124.224"


void onMessage(void* client, mqtt_msg_t *msg);
// mqtt tls config handle
static mqtt_tls_param_t g_tls;

// mqtt client handle
mqtt_client_t* pClientHandle = NULL;

// mqtt client parameters
mqtt_client_config_t clientConfig;

// Read the value of the given gpio port

int gpio_read(int port)
{
  char buf[4];
  char devpath[16];
  snprintf(devpath, 16, "/dev/gpio%d", port);
  int fd = open(devpath, O_RDWR);
  if (fd < 0)
  {
    printf("fd open fail\n");
    return -1;
  }

  if (read(fd, buf, sizeof(buf)) < 0)
  {
    printf("read error\n");
    return -1;
  }
  close(fd);

  return buf[0] == '1';
}

// Write (toggle) the value of given gpio port.
void gpio_write(int port)
{
  int value = 0;
  char str[4];
  static char devpath[16];
  int curValue = gpio_read(port);
  printf("Current value of the gpio port%d is %d\n",port,curValue);
  if (port == 45 || port == 49) {
	  if (curValue <= 0)
	      value = 1;
	    else if (curValue == 1)
	      value = 0;

	    snprintf(devpath, 16, "/dev/gpio%d", port);
	    int fd = open(devpath, O_RDWR);

	    ioctl(fd, GPIOIOC_SET_DIRECTION, GPIO_DIRECTION_OUT);

	    write(fd, str, snprintf(str, 4, "%d", value != 0) + 1);

	    close(fd);
  } else {
	  if (curValue == 1) {
	  	  value = 0;
	  	  snprintf(devpath, 16, "/dev/gpio%d", port);
	  	  int fd = open(devpath, O_RDWR);

	  	  ioctl(fd, GPIOIOC_SET_DIRECTION, GPIO_DIRECTION_OUT);

	  	  write(fd, str, snprintf(str, 4, "%d", value != 0) + 1);

	  	  close(fd);
	    }
  }
}

void turnOff(int port)
{
	int value = 1;
		  char str[4];
		  static char devpath[16];
		  int curValue = gpio_read(port);
		  printf("Fan: %d \n", curValue);
		  if (curValue == 0) {

			  snprintf(devpath, 16, "/dev/gpio%d", port);
			  int fd = open(devpath, O_RDWR);

			  ioctl(fd, GPIOIOC_SET_DIRECTION, GPIO_DIRECTION_OUT);

			  write(fd, str, snprintf(str, 4, "%d", value != 0) + 1);

			  close(fd);
		  }
}

// mqtt client on connect callback
void onConnect(void* client, int result)
{
  printf("mqtt client connected to the server\n");
}

// mqtt client on disconnect callback
void onDisconnect(void* client, int result)
{
  printf("mqtt client disconnected from the server\n");
}



// Utility function to configure mqtt client
void initializeConfigUtil(void)
{
  uint8_t macId[IFHWADDRLEN];
  int result = netlib_getmacaddr("wl1", macId);
  if (result < 0)
  {
    printf("Get MAC Address failed. Assigning \
        Client ID as 123456789");
    clientConfig.client_id =
        DEFAULT_CLIENT_ID; // MAC id Artik 053
  }
  else
  {
    printf("MAC: %02x:%02x:%02x:%02x:%02x:%02x\n",
        ((uint8_t *) macId)[0],
        ((uint8_t *) macId)[1], ((uint8_t *) macId)[2],
        ((uint8_t *) macId)[3], ((uint8_t *) macId)[4],
        ((uint8_t *) macId)[5]);
    char buf[12];
    sprintf(buf, "%02x%02x%02x%02x%02x%02x",
        ((uint8_t *) macId)[0],
        ((uint8_t *) macId)[1], ((uint8_t *) macId)[2],
        ((uint8_t *) macId)[3], ((uint8_t *) macId)[4],
        ((uint8_t *) macId)[5]);
    clientConfig.client_id = buf; // MAC id Artik 053
    clientConfig.user_name = DEVICE_ID;
    clientConfig.password = DEVICE_TOKEN;
    clientConfig.clean_session = true; // check

    clientConfig.protocol_version = MQTT_PROTOCOL_VERSION_31;
    g_tls.ca_cert = mqtt_get_ca_certificate();  //the pointer of ca_cert buffer
    g_tls.ca_cert_len = mqtt_get_ca_certificate_size(); // the length of ca_cert buffer


    g_tls.cert = NULL;
    g_tls.cert_len = 0;


    g_tls.key = NULL;
    g_tls.key_len = 0;

    printf("Registering mqtt client with id = %s\n", buf);
  }
  clientConfig.on_connect = (void*) onConnect;
  clientConfig.on_disconnect = (void*) onDisconnect;
  clientConfig.on_message = (void*) onMessage;
  clientConfig.tls = &g_tls;
  //printf("Size of CA is %d\n",g_tls.ca_cert_len);
}
