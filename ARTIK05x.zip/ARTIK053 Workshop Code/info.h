/*
* FIX THE FOLLOWING
*
*/
#define DEVICE_TOKEN "_your_DEVICE_TOKEN_goes_here_"
#define DEVICE_ID "_your_DEVICE_ID_goes_here_"
#define ACTION_TOPIC "/v1.1/actions/_your_DEVICE_ID_goes_here_"
#define MESSAGE_TOPIC "/v1.1/messages/_your_DEVICE_ID_goes_here_"
