/****************************************************************************
 *
 * Copyright 2016 Samsung Electronics All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 */

#include <tinyara/config.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "wifi.h"
#include "keys.h"
#include "util.h"
#include <tinyara/pwm.h>
#include <tinyara/analog/adc.h>
#include <tinyara/analog/ioctl.h>
#include <apps/netutils/dhcpc.h>
#include <apps/netutils/ntpclient.h>


#define FAN_PORT 41
// mqtt client on message callback
void onMessage(void* client, mqtt_msg_t *msg)
{
  printf("mqtt client on message received\n");
  mqtt_client_t *mqtt_client = (mqtt_client_t *)client;

  if (mqtt_client == NULL || mqtt_client->config == NULL)
  {
    printf("message callback: is NULL.\n");
    return;
  }

  if (msg->payload_len)
  {
    printf("Topic - %s , payload -  %s\n", msg->topic, msg->payload);
  } else
  {
    printf(">>> message callback: payload_len is 0\n");
  }
  char buf[msg->payload_len];
  strcpy(buf,msg->payload);

  if(strstr(buf,"Fan") != NULL)
  {
	  printf("Toggling the Fan\n");
	 // TODO: TOGGLE THE FAN
  }
}

// NTP
static struct ntpc_server_conn_s ntp_server_conn[] = {{ NULL, 123 },};

static void ntp_link_error(void)
{
  printf("NTP error: stopping client\n");
  ntpc_stop();
}

int LED_STATE = 0;
int FAN_STATE = 0;



int main(int argc, char *argv[])
{
  // CONNECT TO A WIFI
  bool wifiConnected = false;
  gpio_write(RED_ON_BOARD_LED); // Turn on on board Red LED to indicate no WiFi connection is established
  #ifdef CONFIG_CTRL_IFACE_FIFO
  int ret;

  while(!wifiConnected)
  {
    ret = mkfifo(CONFIG_WPA_CTRL_FIFO_DEV_REQ,
        CONFIG_WPA_CTRL_FIFO_MK_MODE);
    if (ret != 0 && ret != -EEXIST)
    {
      printf("mkfifo error for %s: %s",
          CONFIG_WPA_CTRL_FIFO_DEV_REQ,
          strerror(errno));
    }
    ret = mkfifo(CONFIG_WPA_CTRL_FIFO_DEV_CFM,
        CONFIG_WPA_CTRL_FIFO_MK_MODE);
    if (ret != 0 && ret != -EEXIST)
    {
      printf("mkfifo error for %s: %s",
          CONFIG_WPA_CTRL_FIFO_DEV_CFM,
          strerror(errno));
    }

    ret = mkfifo(CONFIG_WPA_MONITOR_FIFO_DEV,
        CONFIG_WPA_CTRL_FIFO_MK_MODE);
    if (ret != 0 && ret != -EEXIST)
    {
      printf("mkfifo error for %s: %s",
          CONFIG_WPA_MONITOR_FIFO_DEV,
          strerror(errno));
    }
  #endif

    if (start_wifi_interface() == SLSI_STATUS_ERROR)
    {
      printf("Connect Wi-Fi failed. Try Again.\n");
    }
    else
    {
      wifiConnected = true;
      gpio_write(RED_ON_BOARD_LED); // Turn off Red LED to indicate WiFi connection is established
    }
  }

  printf("Connect to Wi-Fi success\n");

  bool mqttConnected = false;
  bool ipObtained = false;
  printf("Get IP address\n");

  struct dhcpc_state state;
  void *dhcp_handle;

  while(!ipObtained)
  {
    dhcp_handle = dhcpc_open(NET_DEVNAME);
    ret = dhcpc_request(dhcp_handle, &state);
    dhcpc_close(dhcp_handle);

    if (ret != OK)
    {
      printf("Failed to get IP address\n");
      printf("Try again\n");
      sleep(1);
    }
    else
    {
      ipObtained = true;
    }
  }
  netlib_set_ipv4addr(NET_DEVNAME, &state.ipaddr);
  netlib_set_ipv4netmask(NET_DEVNAME, &state.netmask);
  netlib_set_dripv4addr(NET_DEVNAME, &state.default_router);

  printf("IP address  %s\n", inet_ntoa(state.ipaddr));

  // NTP
  sleep(1);
  ntp_server_conn[0].hostname = "0.pool.ntp.org";
  if (ntpc_start(ntp_server_conn, ARRAY_SIZE(ntp_server_conn), NTP_REFRESH_PERIOD, ntp_link_error) < 0)
  {
    printf("Failed to start NTP client.\n"
        "The date may be incorrect and lead to undefined behavior\n");
  }
  else
  {
    int num_retries = 10;

    /* Wait for the date to be set */
    while ((ntpc_get_link_status() != NTP_LINK_UP) && --num_retries)
    {
      sleep(2);
    }

    if (!num_retries)
    {
      printf("Failed to reach NTP server.\n"
          "The date may be incorrect and lead to undefined behavior\n");
    }
  }


  initializeConfigUtil();

  pClientHandle = mqtt_init_client(&clientConfig);
  if (pClientHandle == NULL)
  {
    printf("mqtt client handle initialization fail\n");
    return 0;
  }

  while (mqttConnected == false )
  {
    sleep(2);
    // Connect mqtt client to server
    int result = mqtt_connect(pClientHandle,
        SERVER_ADDR, 8883, 60);
    if (result < 0)
    {
      printf("mqtt client connect to server fail - %d\n ",result);
      continue;
    }
    mqttConnected = true;
  }

  bool mqttSubscribe = false;

  // Subscribe to topic of interest
  while (mqttSubscribe == false )
  {
    sleep(2);
    int result = mqtt_subscribe(pClientHandle,
        ACTION_TOPIC, 0);
    if (result < 0)
    {
      printf("mqtt client subscribe to topic failed\n");
      continue;
    }
    mqttSubscribe = true;
    printf("mqtt client Subscribed to the topic successfully\n");

    sleep(2);
  }
  while (1) {
	  int curr_val = gpio_read(42);
	  if (curr_val == 0) {
		  while (gpio_read(42) == 0) {
		  }
		  printf("turning off the fan\n");
		  turnOff(FAN_PORT);
	  }
  }
  return 0;
}
